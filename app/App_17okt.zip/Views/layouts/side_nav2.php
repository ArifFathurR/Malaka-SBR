<div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sidenav shadow-right sidenav-light">
                    <div class="sidenav-menu">
                        <div class="nav accordion" id="accordionSidenav">
                            
                            <!-- Sidenav Menu Heading (Menu Utama)-->
                            <div class="sidenav-menu-heading">Menu Privileges</div>
                            <!-- Sidenav Link (Dashboard)-->
                            <a class="nav-link" href="<?= base_url('survey') ?>">
                                <div class="nav-link-icon"><i data-feather="activity"></i></div>
                                Home
                            </a>

                            <?php if (session()->get('id_role') === '1'): ?>
                            <!-- Sidenav Link (Tables)-->
                            <a class="nav-link" href="<?= base_url('survey/export') ?>">
                                <div class="nav-link-icon"><i data-feather="users"></i></div>
                                Just Admin
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Sidenav Footer-->
                    <div class="sidenav-footer">
                        <div class="sidenav-footer-content">
                            <div class="sidenav-footer-subtitle">Login sebagai:</div>
                            <div class="sidenav-footer-title"><?= session('nama_user'); ?> </div>
                        </div>
                    </div>
                </nav>
            </div>