<?php

namespace App\Controllers;

class Homelogin extends BaseController
{

    public function index()
    {
        $this->session = \Config\Services::session();

        if ($this->session->has('isLogin')) {
            return redirect()->to('usaha');
        }

        // return view('layout/v_login');
        return view('pantau/v_login_depan');
    }

    public function mitra()
    {
        $this->session = \Config\Services::session();

        if ($this->session->has('isLogin')) {
            return redirect()->to('usaha');
        }

        // return view('layout/v_login');
        return view('pantau/v_login_mitra');
    }
    
    public function pegawai_nonsso()
    {
        $this->session = \Config\Services::session();

        if ($this->session->has('isLogin')) {
            return redirect()->to('usaha');
        }

        // return view('layout/v_login');
        return view('pantau/v_login_pegawai_nonSSO');
    }

}
